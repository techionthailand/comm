#!/bin/bash
# ══════════════════════════════════════════════
#  TIO Commission Platform — STOP
#  Double-click this file to stop the platform
# ══════════════════════════════════════════════

cd "$(dirname "$0")"

clear
echo "╔══════════════════════════════════════════╗"
echo "║   TECH ION Commission Platform           ║"
echo "║   Stopping...                            ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# ── Find and stop the backend ──────────────────
PIDS=$(lsof -ti :3001)

if [ -z "$PIDS" ]; then
  echo "ℹ️  Backend is not running."
else
  echo "🛑 Stopping backend server (PID: $PIDS)..."
  kill $PIDS 2>/dev/null

  # Wait a moment and confirm
  sleep 2

  if lsof -i :3001 &> /dev/null; then
    echo "⚠️  Server didn't stop cleanly — forcing..."
    kill -9 $PIDS 2>/dev/null
    sleep 1
  fi

  if lsof -i :3001 &> /dev/null; then
    echo "❌ Could not stop the server."
    echo "   Try closing the START terminal window instead."
  else
    echo "✅ Backend stopped successfully."
  fi
fi

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║   Platform is now offline.               ║"
echo "║   Double-click START.command to restart. ║"
echo "╚══════════════════════════════════════════╝"
echo ""
read -p "Press Enter to close..."
