# TECH ION Commission Platform — Changelog

All notable changes to this project are documented here.  
Format: [Version] — Date — Description

---

## [v2.3.0] — 2026-05-14
### Changed
- Removed "On-in Division" from login page footer (both standalone + full-stack)
- Removed "On-in Division" from PDF report header
- Removed "On-in" from Employees section subtitle
- Renamed default employee from "On-in Sales" → "Sales" in seed + schema
- Removed default credentials hint box from login page (security)

---

## [v2.2.0] — 2026-05-14
### Added
- Auto-deploy webhook server (`server/scripts/webhook.js`)
- Setup script for auto-deploy (`server/scripts/setup-autodeploy.sh`)
- Nginx config file with API proxy + webhook proxy (`server/nginx.conf`)
- Webhook secret verification using HMAC SHA-256
- PM2 managed webhook process `tio-webhook`
### Changed
- `.env.example` updated with webhook environment variables

---

## [v2.1.0] — 2026-05-14
### Added
- Full deployment guide exported as print-to-PDF HTML (`TIO-Commission-Deployment-Guide.html`)
  - Cover page, Table of Contents, 13 sections
  - Architecture diagram, file tree, all commands
  - API reference table, troubleshooting guide
- `server/nginx.conf` template for team deployment

---

## [v2.0.0] — 2026-05-14 — Full-Stack Release
### Added — Backend (`server/`)
- Node.js + Express REST API (`server/server.js`)
- PostgreSQL database with `pg` connection pool (`server/lib/db.js`)
- Commission engine server-side (`server/lib/commission.js`)
- JWT authentication middleware (`server/middleware/auth.js`)
- Role guards: `adminOnly`, `canEdit` middleware
- Routes: `auth`, `deals`, `employees`, `users`, `settings`
- Database schema with 4 tables: `users`, `employees`, `deals`, `settings` (`server/db/schema.sql`)
- Seed script for default admin + viewer users + employee (`server/scripts/seed.js`)
- `package.json` with all dependencies: express, pg, bcrypt, jsonwebtoken, dotenv, cors
- `.env.example` with all required environment variables
### Added — Frontend (`client/`)
- API layer replacing localStorage — all data via `fetch()` calls
- JWT token stored in `localStorage` for session persistence
- Auto session restore on page reload via `GET /api/auth/me`
- `client/css/style.css` — full standalone stylesheet
- `client/js/app.js` — complete frontend logic
### Security
- Passwords hashed with **bcrypt** (cost factor 10) — never stored plain text
- JWT tokens expire in 8 hours
- Role enforcement on both frontend (UI) and backend (API)
- CORS configured to allow only `CLIENT_ORIGIN`

---

## [v1.9.0] — 2026-05-14
### Changed
- PDF + Excel reports: replaced date-only with full **timestamp** (`DD Mon YYYY HH:MM:SS`)
- Applied to both "Generated" field and report footer "Prepared by" line

---

## [v1.8.1] — 2026-05-14
### Fixed
- Excel export: `headerRowIdx` corrected from `3` → `4` (header was on wrong row due to added "Prepared by" title row — column colour styling now applies correctly)
- Users tab: removed conflicting CSS rule `#nav-users { display:none }` that prevented JS from showing the tab for admin role — reverted to inline `style="display:none"` controlled by JS only

---

## [v1.8.0] — 2026-05-14
### Added
- **User Management** section (Admin only — 👥 Users tab)
  - Role legend cards: Admin / Manager / Viewer with descriptions
  - User list table: name, username, role badge, masked password, edit/delete actions
  - Add / Edit user form with password toggle (show/hide)
  - "You" badge on logged-in user's own row
  - Cannot delete own account protection
  - Duplicate username validation
  - Editing own account updates session live
- `DB.users` array in localStorage data model
- `ROLE_CONFIG` object defining tab visibility and permissions per role
- `applyUserRole()` — dynamically hides nav tabs and injects read-only CSS based on role
- Data migration in `loadData()` — injects default users into old localStorage data automatically
- `fillLogin(u, p)` — click-to-fill credentials on login hint box
### Changed
- Login now checks against `DB.users` (dynamic) instead of hardcoded array
- Viewer role now has **same access as Admin** for viewing (read-only, cannot edit)
- Manager role: hides Users + Settings tabs
- Viewer role: hides Add Deal + Users + Settings tabs, disables all edit buttons via injected CSS

---

## [v1.7.0] — 2026-05-14
### Fixed
- **Critical CSS crash**: stray `</style>` tag inside the main stylesheet caused all CSS to render as raw text on screen. Fixed by merging report styles and main `:root` styles into a single `<style>` block.

---

## [v1.6.0] — 2026-05-14
### Added
- "Prepared by" field on PDF and Excel reports showing the logged-in user's full name
- YTD (Year-to-Date) summary section on reports:
  - Annual Target
  - Total Sales YTD
  - Target Achievement %
  - Average Margin YTD
  - Total Commission YTD
  - This Period Commission
- `getYTDSummary(empId, year)` helper function
### Removed
- GP (Gross Profit) column removed from PDF and Excel report output

---

## [v1.5.0] — 2026-05-14
### Added
- **PDF Export** — `window.print()` with A4 landscape `@media print` CSS
- **Excel Export** — SheetJS (`xlsx-0.20.3`) with colour-coded header row
  - Blue: No./Project/Customer/Receipt/Date columns
  - Red: Sale Price column
  - Purple: Margin/Rate columns
  - Green: Total Commission column
- Professional report layout matching original Excel format:
  - Company logo + name header
  - Employee name + period + generated date
  - Deals table (no GP column)
  - Net Commission Paid row
  - YTD Summary section
  - Confidential footer
- Report filters: Employee, Month, Year selectors
- Report preview panel before export

---

## [v1.4.0] — 2026-05-14
### Added
- Per-employee individual annual sales targets (replaced global target)
- `getEmpTarget(emp)` helper — falls back to `settings.defaultTarget` if employee has no target set
- Inline target editing directly in the Employees table (click ✏️ → edit in-cell → save)
- `openEmpTargetEdit()`, `saveEmpTargetInline()`, `cancelEmpTargetEdit()` functions
- Target progress bar on Dashboard scoped to selected employee
- Target Achievement % stat card on Dashboard
- Employee-specific target shown in stat card subtitle

---

## [v1.3.0] — 2026-05-14
### Added
- **Login system** with session persistence via `sessionStorage`
- Login page with username/password fields, show/hide password toggle
- `doLogin()` — authenticates against user store, fades in app on success
- `doLogout()` — clears session, fades back to login page
- Session auto-restore on page refresh (reads from `sessionStorage`)
- Mock credentials: `admin / TechIon@2026` and `viewer / View#2026`
- Credentials hint box on login page (removed in v2.3.0)

---

## [v1.2.0] — 2026-05-14
### Changed
- Header badge renamed from "On-in" → "Employee"
- Employee selector in header to switch view per salesperson
- `updateHeaderBadge()` syncs header selector with Dashboard employee filter

---

## [v1.1.0] — 2026-05-14
### Added
- TECH ION company logo in header fetched from `techion.co.th`
- Company branding: "TECH ION · Commission Management Platform" in header
- Gradient header background (`#1e3a8a` → `#1a56db`)
### Changed
- Header layout redesigned with logo + brand name + employee badge + user info

---

## [v1.0.0] — 2026-05-14 — Initial Release
### Added
- Single-file HTML platform (`TIO-Commission-Platform.html`) built from Excel commission data
- **Dashboard** with 4 KPI stat cards: Total Sales, Total GP, Total Commission, Target Progress
- **Deals** table with month/employee filters
- **Add Deal** form with commission preview calculator
- **Commission Engine**:
  - `calcCommRate(marginPct)` — rate = margin %, capped at `maxRate`, 0 below `minMargin`
  - `calcCommAmount(gp, marginPct)` — GP × rate
- **Employees** section — add/edit/delete salespersons with colour badges
- **Commission Rules** table — rate lookup by margin %
- **Settings** — configurable `defaultTarget`, `minMargin`, `maxRate`
- `localStorage` persistence with key `tio_commission_v2`
- 2 sample deals pre-loaded:
  - Elastic Enterprise License — YIP IN SOI — ฿1,350,000 — 7.27% margin
  - Implement Commvault — SiS — ฿200,000 — 13.23% margin
- Toast notifications for all save/delete actions
- Responsive layout with sticky header + nav bar
- SheetJS CDN loaded for future Excel export

---

## Project Info

| Item | Detail |
|---|---|
| Repository | https://github.com/techionthailand/comm |
| Deploy path | `/data/appz/comm` (frontend) · `/data/appz/comm-api` (backend) |
| API port | `3001` |
| Webhook port | `3002` |
| Database | PostgreSQL · `tio_commission` |
| Started | May 2026 |
