#!/bin/bash
# ══════════════════════════════════════════════════════
# TIO Commission Platform — Auto Deploy Setup Script
# Run once on your server:  bash setup-autodeploy.sh
# ══════════════════════════════════════════════════════

set -e

REPO_URL="https://github.com/techionthailand/comm"
REPO_DIR="/data/appz/repo"

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║   TIO Auto Deploy Setup                  ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# 1. Clone the repo to a local mirror
echo "📥 Cloning repo to ${REPO_DIR}..."
if [ -d "$REPO_DIR/.git" ]; then
  echo "   Repo already exists — pulling latest..."
  git -C "$REPO_DIR" pull origin main
else
  git clone "$REPO_URL" "$REPO_DIR"
fi

echo ""

# 2. Generate a webhook secret
WEBHOOK_SECRET=$(node -e "console.log(require('crypto').randomBytes(24).toString('hex'))")
echo "🔑 Generated webhook secret:"
echo "   $WEBHOOK_SECRET"
echo "   (Save this — you'll need it in GitHub webhook settings)"
echo ""

# 3. Add to .env
ENV_FILE="/data/appz/comm-api/.env"
if grep -q "WEBHOOK_SECRET" "$ENV_FILE" 2>/dev/null; then
  echo "ℹ .env already has webhook config — skipping"
else
  echo "" >> "$ENV_FILE"
  echo "# Auto-deploy webhook" >> "$ENV_FILE"
  echo "WEBHOOK_PORT=3002" >> "$ENV_FILE"
  echo "WEBHOOK_SECRET=$WEBHOOK_SECRET" >> "$ENV_FILE"
  echo "REPO_DIR=$REPO_DIR" >> "$ENV_FILE"
  echo "CLIENT_DEST=/data/appz/comm" >> "$ENV_FILE"
  echo "SERVER_DEST=/data/appz/comm-api" >> "$ENV_FILE"
  echo "DEPLOY_BRANCH=main" >> "$ENV_FILE"
  echo "✅ Webhook config added to .env"
fi

echo ""

# 4. Start webhook server with PM2
echo "🚀 Starting webhook server..."
cd /data/appz/comm-api
pm2 start scripts/webhook.js --name tio-webhook
pm2 save

echo ""
echo "✅ Auto-deploy setup complete!"
echo ""
echo "══════════════════════════════════════════════"
echo "NEXT STEP — Add webhook in GitHub:"
echo ""
echo "  URL:         https://yourdomain.com/webhook"
echo "  Secret:      $WEBHOOK_SECRET"
echo "  Content type: application/json"
echo "  Events:       Just the push event"
echo "══════════════════════════════════════════════"
echo ""
