/**
 * TIO Commission Platform — Auto Deploy Webhook
 * Listens for GitHub push events and deploys automatically.
 *
 * Run with PM2:
 *   pm2 start scripts/webhook.js --name tio-webhook
 */

require('dotenv').config({ path: require('path').join(__dirname, '../.env') });
const http   = require('http');
const crypto = require('crypto');
const { execSync } = require('child_process');

const PORT          = process.env.WEBHOOK_PORT   || 3002;
const SECRET        = process.env.WEBHOOK_SECRET || '';
const REPO_DIR      = process.env.REPO_DIR       || '/data/appz/repo';
const CLIENT_DEST   = process.env.CLIENT_DEST    || '/data/appz/comm';
const SERVER_DEST   = process.env.SERVER_DEST    || '/data/appz/comm-api';
const BRANCH        = process.env.DEPLOY_BRANCH  || 'main';

function log(msg) {
  console.log(`[${new Date().toISOString()}] ${msg}`);
}

function verifySignature(payload, signature) {
  if (!SECRET) return true; // skip verification if no secret set
  const hmac = crypto.createHmac('sha256', SECRET);
  const digest = 'sha256=' + hmac.update(payload).digest('hex');
  try {
    return crypto.timingSafeEqual(Buffer.from(digest), Buffer.from(signature));
  } catch {
    return false;
  }
}

function deploy() {
  log('🚀 Deploy started...');

  try {
    // 1. Pull latest code
    log('📥 Pulling latest code from GitHub...');
    execSync(`git -C ${REPO_DIR} fetch origin ${BRANCH}`, { stdio: 'inherit' });
    execSync(`git -C ${REPO_DIR} reset --hard origin/${BRANCH}`, { stdio: 'inherit' });

    // 2. Copy client files → /data/appz/comm
    log('📂 Copying client files...');
    execSync(`cp -r ${REPO_DIR}/client/. ${CLIENT_DEST}/`, { stdio: 'inherit' });

    // 3. Copy server files → /data/appz/comm-api
    log('📂 Copying server files...');
    execSync(`cp -r ${REPO_DIR}/server/. ${SERVER_DEST}/`, { stdio: 'inherit' });

    // 4. Install any new npm packages
    log('📦 Installing packages...');
    execSync(`cd ${SERVER_DEST} && npm install --production`, { stdio: 'inherit' });

    // 5. Restart API
    log('🔄 Restarting API...');
    execSync('pm2 restart tio-api', { stdio: 'inherit' });

    log('✅ Deploy complete!');
    return { success: true };
  } catch (err) {
    log('❌ Deploy failed: ' + err.message);
    return { success: false, error: err.message };
  }
}

// ── HTTP Server ─────────────────────────────────────
const server = http.createServer((req, res) => {

  // Health check
  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok', time: new Date().toISOString() }));
    return;
  }

  // Only accept POST /deploy
  if (req.method !== 'POST' || req.url !== '/deploy') {
    res.writeHead(404); res.end('Not found');
    return;
  }

  let body = '';
  req.on('data', chunk => { body += chunk; });
  req.on('end', () => {
    // Verify GitHub signature
    const signature = req.headers['x-hub-signature-256'];
    if (SECRET && (!signature || !verifySignature(body, signature))) {
      log('⚠ Invalid webhook signature — rejected');
      res.writeHead(401); res.end('Unauthorized');
      return;
    }

    // Only deploy on push to main branch
    let payload;
    try { payload = JSON.parse(body); } catch { payload = {}; }

    const pushedBranch = (payload.ref || '').replace('refs/heads/', '');
    if (pushedBranch && pushedBranch !== BRANCH) {
      log(`ℹ Push to branch "${pushedBranch}" — skipped (watching: ${BRANCH})`);
      res.writeHead(200); res.end('Skipped — not target branch');
      return;
    }

    log(`📬 Webhook received — push to ${pushedBranch || 'unknown branch'}`);
    res.writeHead(200); res.end('Deploy triggered');

    // Run deploy async (don't block the response)
    setImmediate(deploy);
  });
});

server.listen(PORT, () => {
  log(`🎣 Webhook server listening on port ${PORT}`);
  log(`   Endpoint : POST http://localhost:${PORT}/deploy`);
  log(`   Repo dir : ${REPO_DIR}`);
  log(`   Client   : ${CLIENT_DEST}`);
  log(`   Server   : ${SERVER_DEST}`);
  log(`   Branch   : ${BRANCH}`);
});
