#!/bin/bash
# ══════════════════════════════════════════════
#  TIO Commission Platform — START
#  Double-click this file to start the platform
# ══════════════════════════════════════════════

cd "$(dirname "$0")"

clear
echo "╔══════════════════════════════════════════╗"
echo "║   TECH ION Commission Platform           ║"
echo "║   Starting up...                         ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# ── Check if already running ───────────────────
if lsof -i :3001 &> /dev/null; then
  echo "ℹ️  Backend is already running on port 3001"
else
  # ── Start backend ──────────────────────────────
  echo "🚀 Starting backend API..."
  cd server
  node server.js &
  SERVER_PID=$!
  cd ..

  # Wait for it to be ready
  echo -n "   Waiting for API to start"
  for i in {1..15}; do
    sleep 1
    echo -n "."
    if curl -s http://localhost:3001/api/health > /dev/null 2>&1; then
      break
    fi
  done
  echo ""

  # Check if it started successfully
  if ! curl -s http://localhost:3001/api/health > /dev/null 2>&1; then
    echo "❌ Backend failed to start."
    echo "   Check that your server/.env file has the correct database settings."
    echo ""
    read -p "Press Enter to close..."
    exit 1
  fi
fi

echo "✅ Backend API is running"

# ── Open app in browser ────────────────────────
echo ""
echo "🌐 Opening app in browser..."
sleep 1
open "http://localhost:3001"

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║   ✅ Platform is running!                ║"
echo "║                                          ║"
echo "║   URL:  http://localhost:3001            ║"
echo "║   User: admin                            ║"
echo "║   Pass: TechIon@2026                     ║"
echo "║                                          ║"
echo "║   Keep this window open.                 ║"
echo "║   Close it to stop the server.           ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# Keep running until user closes the window
wait $SERVER_PID
